# Prediction Market Lab — Roadmap Discussion & Priority Order

This document reviews the proposed architecture roadmap and provides a prioritized implementation plan based on what we already have, what's blocking us today, and what delivers measurable value fastest.

---

## ✅ What We Already Have (Foundation)

| Component          | Status     | Notes                                        |
| ------------------ | ---------- | -------------------------------------------- |
| Market scanning    | ✅ Done    | Kalshi + Polymarket clients with pagination  |
| Basic filters      | ✅ Done    | Volume, liquidity, price bounds              |
| LLM analysis       | ✅ Done    | Claude + OpenAI, config-driven, cost-limited |
| Signal generation  | ✅ Done    | Edge + confidence thresholds                 |
| Kelly sizing       | ✅ Done    | Fractional Kelly with caps                   |
| Risk limits        | ✅ Partial | max_positions, max_position_size             |
| Dry-run execution  | ✅ Done    | Simulates trades, logs "would execute"       |
| Cycle JSON reports | ✅ Done    | Per-market stats, filter results, signals    |

---

## 🚧 Current Blockers

1. **Rate limits** — Kalshi throttles us even with sequential orderbook calls
2. **No persistence** — Each run is stateless; can't compute price changes or track history
3. **No outcome tracking** — We don't know if our signals were right after markets resolve
4. **Edge calculation uses mid-price** — Not execution-aware (no spread/fees)

---

## 📋 Proposed Roadmap vs. My Recommended Order

### Your AI's Suggested Phases

| Phase                | Description                                  | My Priority                           |
| -------------------- | -------------------------------------------- | ------------------------------------- |
| 1                    | Snapshot persistence                         | 🔴 **Do first**                       |
| 2                    | Execution-aware edge                         | 🟡 After snapshots                    |
| 3                    | Probability model interface                  | 🟡 After baselines work               |
| 4                    | Calibration tracking                         | 🟡 After paper portfolio              |
| 5                    | Risk controls                                | 🟢 Extend what exists                 |
| Paper trading engine | Structured signal logging + outcome tracking | 🔴 **Do first** (alongside snapshots) |

---

## 🎯 My Recommended Priority Order

### **Sprint 1: Data Foundation (Weeks 1-2)**

**Goal:** Stop being stateless. Create the dataset everything else depends on.

| Task                                  | Why                                                                      | Complexity |
| ------------------------------------- | ------------------------------------------------------------------------ | ---------- |
| **1.1 Add "scan-only" mode**          | Avoid orderbook calls → no rate limits; just `/markets` data             | Low        |
| **1.2 Snapshot persistence (SQLite)** | Store `{timestamp, ticker, price, volume, liquidity, end_date}` per scan | Medium     |
| **1.3 Paper position logging**        | When signal generated, persist it as a "paper trade" with entry details  | Medium     |

**Deliverable:** You can run `scan` mode hourly without getting rate-limited, and you accumulate a clean dataset.

---

### **Sprint 2: Measurability (Weeks 3-4)**

**Goal:** Be able to answer "were my predictions any good?"

| Task                               | Why                                                      | Complexity |
| ---------------------------------- | -------------------------------------------------------- | ---------- |
| **2.1 Outcome reconciliation**     | Fetch resolved market outcomes, match to paper positions | Medium     |
| **2.2 Brier score computation**    | `(predicted_prob - outcome)^2` per signal                | Low        |
| **2.3 Calibration summary report** | Rolling accuracy, edge decay vs time-to-expiry           | Medium     |

**Deliverable:** After 50–100 resolved paper trades, you have a calibration score and know if LLM or baseline is better.

---

### **Sprint 3: Execution-Aware Edge (Weeks 5-6)**

**Goal:** Edge should reflect what you'd actually pay, not mid-price fantasy.

| Task                              | Why                                                                      | Complexity |
| --------------------------------- | ------------------------------------------------------------------------ | ---------- |
| **3.1 Capture bid/ask on subset** | Only fetch orderbooks for top N markets (by volume) to avoid rate limits | Medium     |
| **3.2 Spread-aware edge calc**    | `edge = model_prob - best_ask` for YES buys                              | Low        |
| **3.3 Add spread quality filter** | Reject markets where spread > X% of mid                                  | Low        |

**Deliverable:** Signals only fire when there's a real tradable edge after spread.

---

### **Sprint 4: Probability Model Interface (Weeks 7-8)**

**Goal:** Make LLM one of several models, not the oracle.

| Task                                         | Why                                                  | Complexity |
| -------------------------------------------- | ---------------------------------------------------- | ---------- |
| **4.1 Define `ProbabilityModel` interface**  | `estimate(market) → {prob, confidence, explanation}` | Low        |
| **4.2 Implement market-implied baseline**    | `prob = price` (measures if you beat the market)     | Trivial    |
| **4.3 Implement heuristic baseline**         | Penalize low liquidity, wide spread, near-expiry     | Low        |
| **4.4 Compare models in calibration report** | Side-by-side Brier scores                            | Medium     |

**Deliverable:** You can objectively say "LLM beats/loses to baseline by X Brier points."

---

### **Sprint 5: Risk & Controls (Weeks 9-10)**

**Goal:** Discipline before live capital.

| Task                                 | Why                                           | Complexity |
| ------------------------------------ | --------------------------------------------- | ---------- |
| **5.1 Max daily drawdown guardrail** | Auto-stop if paper PnL drops > X% in a day    | Low        |
| **5.2 Category exposure limits**     | Don't over-concentrate in one event type      | Medium     |
| **5.3 Event grouping**               | Normalize tickers to events for exposure calc | Medium     |

**Deliverable:** Paper trading engine has discipline guardrails identical to what live would use.

---

### **Sprint 6: Controlled Live Capital (Future)**

**Prerequisites before enabling:**

- [ ] 100+ resolved paper trades
- [ ] Brier score better than market-implied baseline
- [ ] Spread-aware edge implemented
- [ ] Drawdown guardrail tested

---

## 🛑 What NOT To Do Yet

| Avoid                              | Why                                   |
| ---------------------------------- | ------------------------------------- |
| Logistic regression / ML models    | No labeled dataset yet                |
| Monte Carlo simulations            | Overkill without calibration baseline |
| Multiple market categories at once | Depth > breadth                       |
| Web dashboard                      | JSON + notebook is enough for now     |
| Complex arbitrage detection        | Need stable single-platform first     |

---

## 📁 Proposed Feature/Mode Structure

Instead of one interactive script, evolve toward:

```
python -m main.cli scan        # Cheap scan, no orderbooks, writes snapshots
python -m main.cli analyze     # Scan + LLM analysis on top N markets
python -m main.cli paper-trade # Full pipeline, logs paper positions
python -m main.cli report      # Generate calibration/performance summary
```

Each mode is a constrained, repeatable operation with clear inputs/outputs.

---

## 🗓️ Summary: First 3 Things To Build

1. **Scan-only mode** — bypass orderbooks, no rate limits, accumulate data
2. **SQLite snapshot storage** — persist every scan for time-series analysis
3. **Paper position logging** — record every signal as a trackable paper trade

Everything else (calibration, spread-aware edge, model interface) builds on these three.

---

## 💬 Discussion Points

1. **Storage choice:** SQLite vs JSONL? I recommend SQLite (queries, indexes, single file).
2. **Scan frequency:** Hourly? Daily? Depends on rate limits and how fast markets move.
3. **Vertical focus:** The plan suggests picking ONE category (sports, politics, macro). Which interests you most?
4. **LLM role:** Keep as probability estimator for now, or immediately move to feature-extraction only?

Let me know your thoughts and I'll start implementing Sprint 1.
