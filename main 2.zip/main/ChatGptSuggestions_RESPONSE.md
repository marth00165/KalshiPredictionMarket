# Response to "Kalshi Edge Engine — Serious Market Research Directive"

**Date:** February 11, 2026  
**Status:** Planning Phase — No code changes until priorities confirmed

---

## Executive Summary

The GPT-generated "Kalshi Edge Engine" document is an excellent strategic framework. It correctly identifies the core discipline required to move from "AI market scanner" to "quant research lab."

This response:

1. Maps each phase to our current repo state
2. Identifies what's already done, partially done, or missing
3. Proposes a pragmatic implementation order
4. Raises decisions we need to make before coding

---

## Current Repo Foundation (What We Already Have)

| Capability               | Status  | Notes                                                   |
| ------------------------ | ------- | ------------------------------------------------------- |
| Market scanning (Kalshi) | ✅ Done | Async API client with pagination                        |
| Data normalization       | ✅ Done | `MarketData`, `FairValueEstimate`, `TradeSignal` models |
| Basic filters            | ✅ Done | Volume, liquidity, price bounds                         |
| LLM analysis             | ✅ Done | OpenAI/Claude, batched with cost limit                  |
| Cycle JSON reports       | ✅ Done | Markets, filter results, signals → `reports/`           |
| Edge calculation         | ✅ Done | probability - market_price                              |
| Kelly sizing             | ✅ Done | Fractional Kelly with caps                              |
| Dry-run execution        | ✅ Done | Simulates and logs "would execute"                      |
| Bundle market filtering  | ✅ Done | Excludes noisy extended sports markets                  |

**Operational Reality:**

- Rate limiting is aggressive (even sequential calls hit 429s)
- Orderbook calls are expensive and slow
- Many markets have 0 volume/liquidity (filter thresholds may be too strict)

---

## Phase-by-Phase Analysis

### Phase 0 — Specialization Requirement

> "Choose ONE vertical for 90 days"

**My Take:** Agree 100%. Depth > breadth.

**Decision Made:** You chose **Sports + Politics**. I recommend:

- **Primary:** Politics (higher volume, more predictable resolution schedules)
- **Secondary:** Sports (NBA props, once political foundation is solid)

**Action Required:** Confirm this vertical focus before we proceed.

---

### Phase 1 — Historical Data Acquisition

> "Pull 1–2 years of resolved markets"

**Reality Check:** Kalshi doesn't have a public historical API. Options:

1. **Start collecting now** — we can snapshot resolved markets going forward
2. **Research third-party sources** — some academic datasets exist
3. **Build from our own snapshots** — slower but 100% reliable

**What We Can Do:**

- Query resolved markets via `status=closed` filter (if API supports)
- Store final outcome + settlement price when markets close
- Build our own historical dataset over time

**Action Required:** Decide if we research external historical data or just start collecting.

---

### Phase 2 — Snapshot Persistence (NON-NEGOTIABLE)

> "Implement persistent time-series storage"

**Status:** NOT IMPLEMENTED — this is the biggest gap.

**Proposed Schema (SQLite):**

```sql
CREATE TABLE market_snapshots (
    id INTEGER PRIMARY KEY,
    ticker TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    yes_price REAL,
    best_bid REAL,
    best_ask REAL,
    spread REAL,
    volume INTEGER,
    liquidity INTEGER,
    open_interest INTEGER,
    expires_at TEXT,
    category TEXT,
    UNIQUE(ticker, timestamp)
);

CREATE TABLE paper_positions (
    id INTEGER PRIMARY KEY,
    ticker TEXT NOT NULL,
    entry_time TEXT NOT NULL,
    entry_price REAL,
    model_probability REAL,
    market_probability REAL,
    edge REAL,
    confidence REAL,
    position_size REAL,
    entry_spread REAL,
    side TEXT,
    resolved INTEGER DEFAULT 0,
    outcome INTEGER,
    realized_pnl REAL,
    brier_score REAL
);
```

**Two-Tier Approach (to manage rate limits):**

- **Tier 1 (hourly):** All open markets — basic info only (no bid/ask)
- **Tier 2 (on-demand):** Watchlist markets — full orderbook snapshot

**Action Required:** Confirm SQLite is acceptable (vs Postgres, JSONL, etc.)

---

### Phase 3 — Execution-Aware Edge

> "Edge must be calculated against executable price"

**Status:** Partially done — we calculate edge vs mid/last price, but not vs best_ask.

**Fix:**

```python
# Current (misleading)
edge = model_probability - yes_price

# Correct (for buying YES)
edge = model_probability - best_ask_price - fees
```

**Implementation:** Add `spread_aware_edge()` method once we persist bid/ask.

---

### Phase 4 — Probability Model Discipline

> "Define modular interface, implement baselines first"

**Status:** LLM is currently the only "model" — no baselines, no comparison.

**Proposed Interface:**

```python
class ProbabilityModel(Protocol):
    def estimate(self, market: MarketData, context: dict) -> ModelEstimate:
        """Returns probability, confidence, explanation, features_used"""
        ...
```

**Baseline Models to Implement:**

1. **MarketImpliedModel** — probability = current_price (the baseline to beat)
2. **HeuristicModel** — adjusts for time-to-expiry, spread, liquidity
3. **LLMFeatureExtractor** — demote LLM from "oracle" to "feature generator"

**Key Discipline:** Every model must report Brier score vs MarketImpliedModel.

---

### Phase 5 — Paper Portfolio Engine

> "Every signal must persist... No live deployment before 100+ resolved paper trades"

**Status:** NOT IMPLEMENTED — critical missing piece.

**What We Need:**

- `paper_positions` table (schema above)
- Outcome reconciliation script (check resolved markets, compute P&L)
- Calibration curve generator (0-10%, 10-20%, etc.)
- Rolling metrics (Brier, Sharpe, drawdown)

**Gate for Live Trading:**

- 100+ resolved paper trades
- Demonstrated calibration improvement vs market baseline
- Controlled drawdown

---

### Phase 6 — Strategy Research

> "Momentum Breakout, Liquidity Fade, Resolution Lag"

**Status:** NOT IMPLEMENTED — requires snapshot history first.

**Three Strategies Identified:**

| Strategy          | Signal                                               | Data Required         |
| ----------------- | ---------------------------------------------------- | --------------------- |
| Momentum Breakout | price_change_1h > X, volume spike, spread tightening | Hourly snapshots      |
| Liquidity Fade    | Sharp move in thin liquidity, elevated spread        | Bid/ask snapshots     |
| Resolution Lag    | Market not priced correctly after public data        | News feed + snapshots |

**Prerequisite:** 2+ weeks of Tier 1 snapshots before strategy backtesting.

---

### Risk Controls

> "max_positions, max_daily_drawdown, Kelly capped at 0.25"

**Status:** Partially implemented.

| Control                   | Status     | Notes                        |
| ------------------------- | ---------- | ---------------------------- |
| max_positions             | ✅ Done    | Config-driven                |
| max_position_size         | ✅ Done    | Config-driven                |
| Kelly cap                 | ✅ Done    | 0.25 max                     |
| max_daily_drawdown        | ❌ Missing | Needs paper portfolio first  |
| max_exposure_per_category | ❌ Missing | Needs category normalization |
| max_notional_per_event    | ❌ Missing | Needs event grouping         |

---

### AI Usage Policy

> "LLMs for feature extraction, not predictive oracles"

**Current Reality:** LLM directly outputs probability + confidence.

**Recommended Transition:**

1. Keep current LLM flow for now (it works)
2. Add baselines alongside it
3. Measure LLM Brier vs baseline Brier
4. If LLM underperforms → demote to feature extraction only

**Key Insight:** The "disciplined" approach is to measure first, then decide — not to rip out LLM usage prematurely.

---

## Recommended Implementation Order (Sprints)

### Sprint 1: Scan-Only Mode + Persistence (1-2 days)

- Add `--scan-only` CLI flag (no orderbooks, no LLM)
- Implement SQLite snapshot storage (Tier 1 schema)
- Store all open markets hourly without rate limit issues

### Sprint 2: Paper Portfolio + Outcome Tracking (2-3 days)

- Add `paper_positions` table
- Record signals as paper trades
- Implement outcome reconciliation (check resolved markets)
- Compute basic Brier score

### Sprint 3: Tier 2 Snapshots + Spread-Aware Edge (1-2 days)

- Add watchlist concept
- Fetch bid/ask only for watchlist markets
- Compute `spread_aware_edge`

### Sprint 4: Baseline Models (1 day)

- Implement `MarketImpliedModel`
- Implement `HeuristicModel`
- Add Brier comparison reports

### Sprint 5: Strategy Research (ongoing)

- After 2+ weeks of snapshots
- Implement momentum/liquidity/lag detectors
- Backtest on collected data

---

## What NOT To Do Yet

| Temptation               | Why Avoid              |
| ------------------------ | ---------------------- |
| Build a dashboard        | No stable schema yet   |
| Add ML models            | No labeled dataset     |
| Go live with real money  | < 100 paper trades     |
| Model multiple verticals | Depth > breadth        |
| Monte Carlo simulations  | Premature without data |

---

## Open Questions (Need Your Input)

1. **Vertical Focus:** Politics primary, Sports secondary — confirmed?
2. **Historical Data:** Research external sources or just start collecting?
3. **Snapshot Frequency:** Hourly (Tier 1) + on-demand (Tier 2) — acceptable?
4. **Storage:** SQLite (single file, easy) — or prefer Postgres/JSONL?
5. **Watchlist Strategy:** Top N by volume? Manual curation? Category-based?

---

## Alignment with GPT's "Success Definition"

| Criterion                                    | Path to Achieve                         |
| -------------------------------------------- | --------------------------------------- |
| Positive EV across 500+ trades               | Paper portfolio + outcome tracking      |
| Brier score beats market baseline            | Baseline models + measurement           |
| Drawdowns controlled                         | Risk controls + daily guardrails        |
| Strategy robust under spread-aware execution | Tier 2 snapshots + execution price edge |

---

## Final Discipline Rule

> "If the system cannot measure, it cannot improve."

Agreed. The entire Sprint 1-2 plan is about **measurement infrastructure** — not prediction improvement.

Build the foundation. Measure everything. Then iterate.

---

_Ready to start coding once you confirm the open questions above._
