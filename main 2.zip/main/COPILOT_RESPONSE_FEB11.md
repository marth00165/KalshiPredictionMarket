# Copilot Response to GPT's Refined Direction

**Date:** February 11, 2026  
**Status:** Decisions locked. Coding starts tomorrow.

---

## Decisions Confirmed ✅

| Question           | GPT's Answer                                              | My Take                                            |
| ------------------ | --------------------------------------------------------- | -------------------------------------------------- |
| Vertical Focus     | Politics only, no secondary                               | Agreed. 90-day commitment.                         |
| Historical Data    | Start collecting now, research external in parallel       | Agreed. No blocking on archives.                   |
| Snapshot Frequency | Tier 1: 60min, Tier 2: 15min                              | Agreed. Faster Tier 2 for spread/momentum signals. |
| Storage            | SQLite, no debate                                         | Agreed. Research lab, not distributed system.      |
| Watchlist          | Auto by volume/liquidity/spread, politics only, top 20-40 | Agreed. No manual curation bias.                   |

---

## New Requirement: Event Grouping

GPT raised a critical point I hadn't explicitly addressed:

> "Politics markets often cluster: same election, same CPI print, same debate outcome."

**Why it matters:**

- Kelly sizing can overexpose correlated bets
- Risk metrics lie without correlation awareness
- Exposure caps fail silently

**Proposed Schema Addition:**

```sql
ALTER TABLE market_snapshots ADD COLUMN event_id TEXT;
ALTER TABLE market_snapshots ADD COLUMN event_category TEXT;
ALTER TABLE market_snapshots ADD COLUMN correlation_group TEXT;
```

**Initial Implementation:**

- Text-based grouping from ticker/title parsing
- Same-day expiry markets → likely same event
- Explicit event tags where Kalshi provides them

This moves to **Sprint 4** (after basic infrastructure works).

---

## Refined Sprint Order

| Sprint | Focus                                | Deliverables                                                         |
| ------ | ------------------------------------ | -------------------------------------------------------------------- |
| **1**  | SQLite + Tier 1 Snapshots            | `market_snapshots` table, hourly collection, politics filter         |
| **2**  | Paper Portfolio + Brier              | `paper_positions` table, outcome reconciliation, calibration metrics |
| **3**  | Tier 2 Watchlist + Spread-aware edge | 15-min bid/ask snapshots, `spread_aware_edge()` calculation          |
| **4**  | Event grouping + exposure controls   | `event_id` parsing, correlated position limits                       |
| **5**  | Baseline model benchmarking          | MarketImpliedModel, HeuristicModel, Brier comparison                 |

**No strategy research until Sprint 3 is complete.**

---

## The Real 30-Day Mission

GPT crystallized it perfectly:

> "Build the cleanest political prediction market dataset you can."

Everything else is secondary. If the dataset is good:

- Modeling becomes tractable
- Backtesting becomes meaningful
- Edge detection becomes measurable

If the dataset is garbage:

- Every model is overfitting noise
- Every backtest is a lie
- Every "edge" is imaginary

---

## What I'll Be Measuring (Not Predicting)

| Metric              | Why It Matters                     |
| ------------------- | ---------------------------------- |
| Market calibration  | Are prices accurate probabilities? |
| Spread dynamics     | When do spreads compress/expand?   |
| Volatility regimes  | High-vol vs low-vol periods        |
| Edge decay          | How fast do mispricings correct?   |
| Resolution patterns | Drift toward outcome over time     |

Prediction is a side effect of understanding these patterns—not the starting point.

---

## Answering GPT's Final Question

> "Are you mentally prepared for the possibility that after 3 months, you discover no persistent edge?"

**Yes.**

That's actually a valuable outcome:

1. It proves the methodology was rigorous
2. It eliminates a class of strategies with confidence
3. It teaches more than false positives would
4. It's infinitely better than losing money on untested intuition

The point isn't to "win"—it's to _know_ whether winning is possible, and why.

If the answer is "no edge exists in political markets with this approach," that's a clean result. Move to a different vertical or a different approach with that knowledge.

If the answer is "no edge exists" but I spent 3 months on vibes without measurement—that's the failure state.

---

## Tomorrow's Kickoff

**Sprint 1 scope:**

1. Create `data/` directory + SQLite database
2. Implement `SnapshotStorage` class
3. Add `--scan-only` CLI mode (no orderbooks, no LLM)
4. Filter to politics markets only
5. Run first Tier 1 snapshot collection
6. Verify data is persisting correctly

**Estimated time:** 2-4 hours

---

## One More Thing

GPT's insight about politics markets is worth internalizing:

> "Political markets often overreact to polling noise, drift slowly toward outcome, exhibit momentum regimes, have resolution ambiguity edges, and have event timing effects."

This means the research vectors are:

- **Polling noise** → contrarian signals when polls move prices too fast
- **Slow drift** → momentum detection over days, not hours
- **Ambiguity** → markets that stay uncertain longer than expected
- **Timing** → calendar effects (debate nights, primary dates, etc.)

All of this requires _data first_, not models.

---

_Locked and ready. See you tomorrow._
