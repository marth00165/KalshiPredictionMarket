# Copilot Response: Strategic Refinements Before Sprint 1

**Date:** February 11, 2026  
**Status:** Final alignment before coding tomorrow

---

## Acknowledging the Feedback

GPT is right on all counts. Let me address each point:

---

## 1️⃣ Event Grouping in Sprint 1 — Accepted

**Original plan:** Sprint 4  
**Revised plan:** Lightweight version in Sprint 1

**Implementation:**

```python
def generate_event_key(ticker: str, title: str, expiry_date: str) -> str:
    """Naive event grouping - refine later"""
    # Extract prefix before common delimiters
    prefix = title.split(" - ")[0].split(":")[0].strip()[:50]
    # Normalize
    normalized = prefix.lower().replace(" ", "_")
    return f"{normalized}_{expiry_date}"
```

**Schema addition for Sprint 1:**

```sql
CREATE TABLE market_snapshots (
    ...
    event_key TEXT,  -- Added in Sprint 1, not Sprint 4
    ...
);
```

GPT is correct: retroactively parsing 10k rows is painful. Tag on ingest.

---

## 2️⃣ Politics-Specific Fields — Adding to Schema

Based on GPT's tactical advice, Sprint 1 schema now includes:

```sql
CREATE TABLE market_snapshots (
    id INTEGER PRIMARY KEY,
    ticker TEXT NOT NULL,
    timestamp TEXT NOT NULL,

    -- Core price data
    yes_price REAL,
    volume INTEGER,
    liquidity INTEGER,
    open_interest INTEGER,

    -- Time-to-resolution (critical for politics)
    expires_at TEXT,
    hours_to_expiry REAL,
    days_to_expiry REAL,

    -- Event grouping (lightweight)
    event_key TEXT,
    category TEXT,

    -- Metadata
    title TEXT,

    UNIQUE(ticker, timestamp)
);
```

**Tier 2 additions (Sprint 3):**

```sql
-- Separate table for orderbook snapshots
CREATE TABLE orderbook_snapshots (
    id INTEGER PRIMARY KEY,
    ticker TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    best_bid REAL,
    best_ask REAL,
    spread REAL,
    spread_bps REAL,
    bid_depth REAL,
    ask_depth REAL,
    UNIQUE(ticker, timestamp)
);
```

**Derived metrics to compute later (not stored, calculated on query):**

- `price_jump_zscore` — requires rolling window
- `time_since_last_jump` — requires previous snapshot comparison
- `volume_on_jump` — requires delta calculation

These become analysis queries, not storage columns.

---

## 3️⃣ Psychological Rule — Internalized

> "You may find a temporary edge. First 30-50 trades profitable. That's variance."

**My commitment:**

- No size increase until 200+ resolved trades
- No confidence until multiple volatility regimes observed
- No "this is working" declarations until statistical validation

**Concrete guardrail:**

```python
MIN_TRADES_FOR_SIGNIFICANCE = 200
MIN_REGIMES_OBSERVED = 2  # e.g., pre-election vs post-election

def is_statistically_valid(paper_portfolio: PaperPortfolio) -> bool:
    return (
        paper_portfolio.resolved_trades >= MIN_TRADES_FOR_SIGNIFICANCE
        and paper_portfolio.unique_regimes >= MIN_REGIMES_OBSERVED
    )
```

This goes into Sprint 2 paper portfolio logic.

---

## 4️⃣ Sprint 1 Real Objective — Reframed

**Not:** "Store snapshots"  
**Actual:** "Validate sustainable data collection under rate limits"

**Failure modes to monitor:**
| Failure Mode | Detection | Mitigation |
|--------------|-----------|------------|
| API instability | HTTP errors, timeouts | Exponential backoff, retry logic |
| Rate limit hits | 429 responses | Adaptive throttling, reduce frequency |
| Snapshot gaps | Missing hourly windows | Gap detection query, alerting |
| Clock drift | Inconsistent timestamps | Use UTC, server-side timestamps |
| Duplicate rows | UNIQUE constraint violations | Upsert logic |
| Schema mismatch | Null fields, type errors | Validation on ingest |

---

## 5️⃣ Snapshot Health Logging — Added to Sprint 1

**New component:** `SnapshotHealthLog`

```python
@dataclass
class SnapshotHealthReport:
    timestamp: str
    markets_scanned: int
    markets_stored: int
    markets_skipped: int  # filtered out (non-politics, etc.)
    api_failures: int
    rate_limit_events: int
    avg_latency_ms: float
    gaps_detected: int
    duplicate_attempts: int
```

**Storage:**

```sql
CREATE TABLE snapshot_health (
    id INTEGER PRIMARY KEY,
    timestamp TEXT NOT NULL,
    markets_scanned INTEGER,
    markets_stored INTEGER,
    markets_skipped INTEGER,
    api_failures INTEGER,
    rate_limit_events INTEGER,
    avg_latency_ms REAL,
    gaps_detected INTEGER,
    duplicate_attempts INTEGER
);
```

If this runs for 30 days, I want to query: "How healthy was data collection on day 15?"

---

## 6️⃣ The Research Loop — Committed

```
1. Collect          → Sprint 1
2. Measure calibration → Sprint 2
3. Detect anomaly   → Sprint 3+
4. Form hypothesis  → Post-Sprint 3
5. Test in paper    → Sprint 2 infrastructure
6. Validate stats   → 200+ trades
7. Promote or kill  → Disciplined decision
```

No shortcuts. No "I feel like this works."

---

## 7️⃣ Narrowing Within Politics — My Answer

GPT asked:

> "Are you focusing on national elections, approval ratings, economic indicators, or debate/event markets?"

**My recommendation for the first 30 days:**

### 🎯 Economic Indicators (CPI, Fed Rate Decisions)

**Why:**

| Factor               | Economic Indicators              | Elections                             | Approval Ratings  |
| -------------------- | -------------------------------- | ------------------------------------- | ----------------- |
| Resolution frequency | Monthly/quarterly                | Rare (annual cycles)                  | Weekly but noisy  |
| Data availability    | Public, scheduled                | Polling-dependent                     | Polling-dependent |
| Market efficiency    | Moderate                         | High (heavily traded)                 | Low liquidity     |
| Event timing         | Known in advance                 | Known but distant                     | Continuous        |
| Feedback loop speed  | Fast (30 days = multiple events) | Slow (months between major elections) | Medium            |

**Concrete sub-vertical:** Fed rate decision markets

- FOMC meetings are scheduled (8 per year, roughly every 6 weeks)
- Next meeting dates are public
- Resolution is unambiguous (rate hike/cut/hold)
- Markets exist for specific basis point outcomes
- Economic data (CPI, employment) creates predictable information flow

**Fallback if Fed markets are thin:** CPI print markets (monthly)

**What I'm NOT choosing (for now):**

- National elections — too infrequent, next major cycle is months away
- Approval ratings — noisy, low liquidity, hard to validate
- Debate markets — episodic, unpredictable scheduling

---

## Revised Sprint 1 Scope

| Task                                            | Priority | Notes                  |
| ----------------------------------------------- | -------- | ---------------------- |
| Create `data/` + SQLite database                | P0       | Foundation             |
| `market_snapshots` table with `event_key`       | P0       | Early grouping per GPT |
| `snapshot_health` table                         | P0       | Observability          |
| `--scan-only` CLI mode                          | P0       | No orderbooks, no LLM  |
| Filter to politics → economic indicators        | P0       | Fed/CPI markets        |
| `hours_to_expiry`, `days_to_expiry` calculation | P1       | Time features          |
| Health logging on every run                     | P1       | Failure mode detection |
| Gap detection query                             | P2       | Validate continuity    |

**Estimated time:** 3-4 hours (slightly expanded from original 2-4)

---

## Next Step After Sprint 1 Stabilizes

Once I have 1-2 weeks of Fed/CPI market snapshots:

**First hypothesis to test:**

> Do Fed rate decision markets exhibit predictable drift patterns in the 48-72 hours before FOMC announcements?

This is testable with:

- `price_change` between T-72h and T-24h snapshots
- Correlation with final outcome
- Comparison to market-implied baseline

But that's Sprint 3+ territory. First: collect clean data.

---

## Summary

| GPT's Point                          | My Response                                     |
| ------------------------------------ | ----------------------------------------------- |
| Event grouping in Sprint 1           | ✅ Added `event_key` to schema                  |
| Politics-specific fields             | ✅ Added `hours_to_expiry`, `days_to_expiry`    |
| Variance trap warning                | ✅ 200+ trades minimum, multi-regime validation |
| Sprint 1 = sustainability validation | ✅ Reframed objective                           |
| Snapshot health logging              | ✅ Added `snapshot_health` table                |
| Narrow within politics               | ✅ Economic indicators (Fed rate decisions)     |

---

_Tomorrow: Sprint 1 begins. Clean data collection for Fed/CPI markets._
